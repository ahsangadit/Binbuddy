<?php

/**
 * The user-specific functionality of the plugin.
 *
 * @link       https://hztech.biz
 * @since      1.0.0
 *
 * @package    Payment_Plugin
 * @subpackage Payment_Plugin/user
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Payment_Plugin
 * @subpackage Payment_Plugin/user
 * @author     HZTECH <info@hztech.biz>
 */
class Payment_Plugin_User
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $plugin_name The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $version The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @param string $plugin_name The name of this plugin.
	 * @param string $version The version of this plugin.
	 *
	 * @since    1.0.0
	 */
	public function __construct( $plugin_name, $version )
	{
		$this->plugin_name = $plugin_name;
		$this->version     = $version;
		add_shortcode( 'stripe_form', array( $this, 'stripe_form' ) );
		add_action( "wp_ajax_stripe_form_pay", array( $this,  "stripe_form_pay") );
		add_action( "wp_ajax_nopriv_stripe_form_pay", array( $this,  "stripe_form_pay") );
		add_action( 'upgrader_process_complete',  array( $this, 'payment_after_update'), 10, 2);
		add_filter('site_transient_update_plugins', array( $this,  'payment_push_update' ));
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/payment-plugin-user.css', array(), $this->version, 'all' );

	}

	public function enqueue_scripts()
	{
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/payment-plugin-user.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_style( 'font-awesome-style', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css' );
	}

	function unserializeForm($str) {
		$strArray = explode("&", $str);
		foreach($strArray as $key => $item) {
			$array = explode("=", $item);
			$returndata[] = $array;
		}
		return $returndata;
	}

	function stripe_form_pay()
	{
		$payment_stripe_id = get_option( 'payment_stripe_id' );
		$payment_stripe_key = get_option( 'payment_stripe_key' );
		define( "STRIPE_SECRET_KEY", $payment_stripe_id );
		define( "STRIPE_PUBLISHABLE_KEY", $payment_stripe_key );
		include( plugin_dir_path( __FILE__ ) . 'inc/StripePayment.php');
		$token = $_POST['token'];
		$form_data = $_POST['form'];
		$form_data = $this->unserializeForm($form_data);
		$fname          = $form_data[0][1];
		$lname          = $form_data[1][1];
		$email          = $form_data[2][1];
		$street        = $form_data[5][1];
		$city          = $form_data[6][1];
		$state         = $form_data[7][1];
		$zip           = $form_data[8][1];
		$invoic_no     = $form_data[9][1];
		$invoice_date  = $form_data[10][1];
		$invoice_amount= $form_data[11][1];

		$cardDetailsAry = [
			'amount' => 2 * 100,
			'currency' => 'usd',
			'description' => 'das',
			'source' => $token,
			'capture' => false,
		];
		if ($token) {
			$stripePayment  = new StripePayment();

			$stripeResponse = $stripePayment->chargeAmountFromCard( $cardDetailsAry );
			$stripeResponse = json_decode( $stripeResponse );
			if ( $stripeResponse->status == 'success' ) {
				$transaction = array(
					'post_title'    => 'Transaction# '. $stripeResponse->data->id,
					'post_status'   => 'publish',
					'post_type'     => 'payments',
				);
				$payment_id = wp_insert_post( $transaction );

				update_post_meta( $payment_id, 'first_name', $fname );
				update_post_meta( $payment_id, 'last_name', $lname );
				update_post_meta( $payment_id, 'email', $email );
				update_post_meta( $payment_id, 'amount', $invoice_amount );
				update_post_meta( $payment_id, 'city', $city );
				update_post_meta( $payment_id, 'state', $state );
				update_post_meta( $payment_id, 'address1', $street );
				update_post_meta( $payment_id, 'date', date("Y-m-d") );
				update_post_meta( $payment_id, 'zip', $zip );
				update_post_meta( $payment_id, 'transaction-id', $stripeResponse->data->id );
				update_post_meta( $_POST['request_id'], 'stripe_payment_id', $stripeResponse->data->id );
				echo json_encode(["status" => "success"]);
			}
			die();
		}
	}

	function stripe_form(){
		ob_start();

		$payment_stripe_id = get_option( 'payment_stripe_id' );
		$payment_stripe_key = get_option( 'payment_stripe_key' );
		define( "STRIPE_SECRET_KEY", $payment_stripe_id );
		define( "STRIPE_PUBLISHABLE_KEY", $payment_stripe_key );
		include( plugin_dir_path( __FILE__ ) . 'inc/StripePayment.php');
		?>

		<script src="https://js.stripe.com/v2/"></script>

		<body>

		<div class="stipepayment_form">
			<form id="frmStripePayment" class="stripe_form_submit" method="POST" >
				<?php if(get_option( 'payment_logo' )){ ?>
					<div class="formheader_img">
						<img src="<?= get_option( 'payment_logo' ); ?>" />
					</div>
				<?php } ?>
				<div class="name_card field_box">
					<label>Name on card</label>
					<input placeholder="First Name" id="fname" name="fname" class="field-half" required />
					<input placeholder="Last Name" id="lname" name="lname" class="field-half" required />
					<input placeholder="Email" id="email" name="email" class="field-full" required />
				</div>

				<div class="card_info  field_box">
					<label>Card Information</label>
					<input placeholder="Card Number" id="stripe-card-number" name="card-number" class="field-half card-number" required />
					<input placeholder="Card Cvc" id="stripe-cvc" name="card-cvc" class="field-half card-cvc" required />
					<input placeholder="Expire Month" id="stripe-month" name="card-expiry-month" class="field-half card-expiry-month" required />
					<input placeholder="Expire Year" id="stripe-year" name="card-expiry-year" class="field-half card-expiry-year" required />
				</div>

				<div class="address_info  field_box">
					<label>Address Information</label>
					<input placeholder="Street" id="address-line1" name="address_line1" class="field-half"  />
					<input placeholder="City" id="address-city" name="address_city" class="field-half"  />
					<input placeholder="State" id="address-state" name="address_state" class="field-half" />
					<input placeholder="ZIP" id="address-zip" name="address_zip" class="field-half"  />
				</div>

				<div class="invoice_info  field_box">
					<label>Invoice Information</label>
					<input placeholder="Invoice Number" id="invoice_number" name="invoice_number" class="field-full"  />
					<input placeholder="Invoice Date" id="invoice_date" name="invoice_date" class="field-half" />
					<input placeholder="Invoice Amount" id="invoice_amount" name="invoice_amount" class="field-half"  />
				</div>
				<div class="contact-row token-row">
				</div>
				<button type="submit">Pay</button>
				<div class="outcome">
					<div class="error"></div>
					<div class="success">
						Success! Your Stripe token is <span class="token"></span>
					</div>
				</div>

			</form>
		</div>

		</body>

		<script>

            jQuery(function ($) {
                Stripe.setPublishableKey("pk_test_oRJf6RQMqYkga3fxQ09enR9d");
                function stripeResponseHandler(status, response) {
                    if (response.error) {
                        $("#submit-btn").show();
                        $("#error-message").html(response.error.message).show();
                    } else {
                        var token = response['id'];
                        $(".token-row").html("<input type='hidden' name='token' value='" + token + "' />");
                        var form = $('#frmStripePayment' ).serialize();
                        jQuery.ajax({
                            type: 'post',
                            url: '/wp-admin/admin-ajax.php',
                            data: {
                                action: 'stripe_form_pay',
                                form  : form,
                                token : token
                            },
                            success: function (response) {
                                var j = $.parseJSON(response);
                                if (j.status == "success") {
                                    location.reload();
                                }
                            },
                            error: function (data) {
                                console.log("11" + data);
                            }

                        });
                    }
                }
                function stripePay() {
                    var token =   Stripe.createToken({
                        number: $('#stripe-card-number').val(),
                        cvc: $('#stripe-cvc').val(),
                        exp_month: $('#stripe-month').val(),
                        exp_year: $('#stripe-year').val()
                    }, stripeResponseHandler);

                    return false;
                }

                $( "#frmStripePayment" ).submit(function( event ) {
                    event.preventDefault();
                    stripePay();
                });

            });
		</script>
		<style>
			.stripe_form_submit {
				padding:65px;
				background:white;
				padding-bottom:100px;
			}

			.group {
				background: white;
				box-shadow: 0 7px 14px 0 rgba(49, 49, 93, 0.10), 0 3px 6px 0 rgba(0, 0, 0, 0.08);
				border-radius: 4px;
				margin-bottom: 20px;
			}

			label {
				position: relative;
				color: #8898AA;
				font-weight: 300;
				height: 40px;
				line-height: 40px;
				display: flex;
				flex-direction: row;
			}

			.group label:not(:last-child) {
				border-bottom: 1px solid #F0F5FA;
			}

			label > span {
				width: 120px;
				text-align: right;
				margin-right: 30px;
			}

			.field {
				background: transparent;
				font-weight: 300;
				border: 0;
				color: #31325F;
				outline: none;
				flex: 1;
				padding-right: 10px;
				padding-left: 10px;
				cursor: text;
			}

			.field::-webkit-input-placeholder {
				color: #CFD7E0;
			}

			.field::-moz-placeholder {
				color: #CFD7E0;
			}

			button {
				float: left;
				display: block;
				background: #666EE8;
				color: white;
				box-shadow: 0 7px 14px 0 rgba(49, 49, 93, 0.10), 0 3px 6px 0 rgba(0, 0, 0, 0.08);
				border-radius: 4px;
				border: 0;
				margin-top: 20px;
				font-size: 15px;
				font-weight: 400;
				width: 100%;
				height: 40px;
				line-height: 0px;
				outline: none;
			}

			button:focus {
				background: #555ABF;
			}

			button:active {
				background: #43458B;
			}

			.outcome {
				float: left;
				width: 100%;
				padding-top: 8px;
				min-height: 24px;
				text-align: center;
			}

			.success,
			.error {
				display: none;
				font-size: 13px;
			}

			.success.visible,
			.error.visible {
				display: inline;
			}

			.error {
				color: #E4584C;
			}

			.success {
				color: #666EE8;
			}

			.success .token {
				font-weight: 500;
				font-size: 13px;
			}

			.stripe_form_submit .group {
				box-shadow: none;
				background: none;
			}

			.stripe_form_submit .group input {
				border: 1px solid #3333;
				padding-left: 10;
			}
			.stripe_form_submit .group label {
				border: none
			}

			.field-full, .field-half {
				height: 45px;
				background: #FFFFFF 0% 0% no-repeat padding-box;
				border: 1px solid #D0D0D0;
				margin: 5px 0px;
				padding: 0 2px;
			}


			.field_box label {
				text-align: left;
				letter-spacing: 0px;
				color: #0C0C0C;
				opacity: 1;
				font-size: 16px;
				font-weight: 600;
				margin: 0 0 0 0;
			}

			.field-full {
				width: 100%;
			}

			.formheader_img {
				text-align: center;
			}

			.formheader_img img {
				margin: 0 auto;
				width: 100px;
			}

			.stripe_form_submit  button {
				background: #000000 0% 0% no-repeat padding-box;
				border: 1px solid #D0D0D0;
				border-radius: 3px;
				opacity: 1;
			}


		</style>
		<?php
		$output = ob_get_clean();
		return $output;
	}

	function payment_after_update( $upgrader_object, $options ) {
		if ( $options['action'] == 'update' && $options['type'] === 'plugin' )  {
			// just clean the cache when new plugin version is installed
			delete_transient( 'misha_upgrade_payment-plugin' );
		}
	}

	function payment_push_update( $transient ){

		if ( empty($transient->checked ) ) {
			return $transient;
		}

		if( false == $remote = get_transient( 'misha_upgrade_payment-plugin' ) ) {

			$remote = wp_remote_get( 'http://45.33.62.49/info.json', array('timeout' => 0,'headers' => array('Accept' => 'application/json' ) )
			);

			if ( !is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && !empty( $remote['body'] ) ) {
				set_transient( 'misha_upgrade_payment-plugin', $remote, 0 ); // 0 hours cache
			}

		}

		if( $remote ) {

			$remote = json_decode( $remote['body'] );
			// your installed plugin version should be on the line below! You can obtain it dynamically of course
			if( $remote && version_compare( '1.0', $remote->version, '<' ) && version_compare($remote->requires, get_bloginfo('version'), '<' ) ) {
				$res = new stdClass();
				$res->slug = 'payment-plugin';
				$res->plugin = 'payment-plugin/payment-plugin.php'; // it could be just YOUR_PLUGIN_SLUG.php if your plugin doesn't have its own directory
				$res->new_version = $remote->version;
				$res->tested = $remote->tested;
				$res->package = $remote->download_url;
				$transient->response[$res->plugin] = $res;
			}

		}
		return $transient;
	}

}

