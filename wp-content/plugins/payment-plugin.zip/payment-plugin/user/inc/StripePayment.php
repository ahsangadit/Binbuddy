<?php

require_once 'vendor/autoload.php';

use \Stripe\Stripe;
use \Stripe\Customer;
use \Stripe\ApiOperations\Create;
use \Stripe\Charge;
use \Stripe\PaymentIntent;
use \Stripe\Transfer;

class StripePayment
{

    private $apiKey;

    private $stripeService;

    public function __construct()
    {
        $this->apiKey = STRIPE_SECRET_KEY;
        $this->stripeService = new \Stripe\Stripe();
        $this->stripeService->setVerifySslCerts(false);
        $this->stripeService->setApiKey($this->apiKey);
    }

    public function addCustomer($customerDetailsAry)
    {

        $customer = new Customer();

        $customerDetails = $customer->create($customerDetailsAry);

        return $customerDetails;
    }

    public function chargeAmountFromCard($cardDetails)
    {
        $charge = new Charge();
        try {
            $result = $charge->create($cardDetails);
            return json_encode(['status'=> 'success', 'data' => $result ]);
        }catch (Exception $e) {
            return json_encode(['status' => 'failed']);
        }


    }

    public function payout(){
        $transfer  = new Transfer();
        $transfer = $transfer->create([
            'amount' => 500,
            'currency' => 'usd',
            'destination' => 'acct_1HSPCHAw6UWfVUCu',
            'transfer_group' => '{ORDER10}',
        ]);
    }

    public function retreive($id){
        $charge = new Charge();
        $retrieve = $charge->retrieve($id);
        $capture = $retrieve->capture();
        return $capture;
    }
}
