<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://hztech.biz
 * @since      1.0.0
 *
 * @package    Payment_Plugin
 * @subpackage Payment_Plugin/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Payment_Plugin
 * @subpackage Payment_Plugin/admin
 * @author     HZTECH <info@hztech.biz>
 */
class Payment_Plugin_Admin
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $plugin_name The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $version The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @param string $plugin_name The name of this plugin.
	 * @param string $version The version of this plugin.
	 *
	 * @since    1.0.0
	 */
	public function __construct( $plugin_name, $version )
	{
		$this->plugin_name = $plugin_name;
		$this->version     = $version;
		add_action( 'init', array( $this, 'create_posttype' ) );
		add_action( 'admin_head', array( $this, 'custom_post_css' ) );
		add_action( 'init', array( $this, 'init_remove_support' ) );
		add_action( 'add_meta_boxes', array( $this, 'remove_publish_metabox' ) );
		add_action( 'edit_form_after_title', array( $this, 'custom_fields_payment' ) );
		add_filter( 'wp_insert_post_data', array( $this, 'filter_post_data' ), '99', 2 );
		add_action('admin_menu', array($this,'add_setting_submenu') );
		add_action( 'admin_init', array( $this,  'payment_plugin_settings') );
		add_filter( 'manage_payments_posts_columns', array( $this, 'smashing_payments_columns' ) );
		add_action( 'manage_payments_posts_custom_column', array( $this, 'custom_payments_column'), 10, 2);
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Payment_Plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Payment_Plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/payment-plugin-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Payment_Plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Payment_Plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/payment-plugin-admin.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_style( 'font-awesome-style', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css' );
	}

	public function create_posttype()
	{

		register_post_type( 'Payments',
		                    array(
			                    'labels'       => array(
				                    'name'          => __( 'Payments' ),
				                    'singular_name' => __( 'Payment' ),
				                    'all_items'     => __( 'All Payments' ),
				                    'add_new_item'  => __( 'Add New Payments' )
			                    ),
			                    'public'       => true,
			                    'has_archive'  => true,
			                    'rewrite'      => array( 'slug' => 'payments' ),
			                    'show_in_rest' => true,
			                    'menu_icon'    => '',

		                    )
		);
	}

	public function add_setting_submenu()
	{
		add_submenu_page(
			'edit.php?post_type=payments', //$parent_slug
			'Settings',  //$page_title
			'Settings',        //$menu_title
			'manage_options',           //$capability
			'payment-settings',//$menu_slug
			array($this,'payment_page')//$function
		);

	}

	function payment_plugin_settings()
	{
		$current_url = home_url() . '/wp-admin/admin.php?page=payment-settings';
		add_option( 'payment_url', $current_url );
		register_setting( 'payment-settings', 'payment_stripe_id' );
		register_setting( 'payment-settings', 'payment_stripe_key' );
		register_setting( 'payment-settings', 'payment_active' );
		register_setting( 'payment-settings', 'payment_amount' );
		register_setting( 'payment-settings', 'payment_bg_color' );
		register_setting( 'payment-settings', 'payment_logo' );
		register_setting( 'payment-settings', 'payment_cancel_payment_url' );


		add_settings_section( 'payment-settings-section', 'Settings', 'payment_plugin_setting_section_callback', 'payment-settings' );

	}


//add_submenu_page callback function

	public function payment_page()
	{
		$payment_stripe_id = get_option( 'payment_stripe_id' );
		$payment_stripe_key = get_option( 'payment_stripe_key' );
		$payment_active = get_option( 'payment_active' );
		$payment_amount = get_option( 'payment_amount' );
		$payment_bg_color = get_option( 'payment_bg_color' );
		$payment_cancel_payment_url = get_option( 'payment_cancel_payment_url' );
		$payment_logo = get_option( 'payment_logo' );
		ob_start(); ?>

		<?php

		if(isset($_POST['submit'])){
			$payment_stripe_id = $_POST['payment_stripe_id'];
			$payment_stripe_key = $_POST['payment_stripe_key'];
			$payment_active = $_POST['payment_active'];
			$payment_amount = $_POST['payment_amount'];
			$payment_bg_color = $_POST['payment_bg_color'];
			$payment_cancel_payment_url= $_POST['payment_cancel_payment_url'];

			update_option('payment_stripe_id',$payment_stripe_id);
			update_option('payment_stripe_key',$payment_stripe_key);
			update_option('payment_active',$payment_active);
			update_option('payment_amount',$payment_amount);
			update_option('payment_bg_color',$payment_bg_color);
			update_option('payment_cancel_payment_url',$payment_cancel_payment_url);

			if($_FILES['payment_logo']['name'] != ''){
				$uploadedfile = $_FILES['payment_logo'];
				$upload_overrides = array( 'test_form' => false );

				$movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
				$imageurl = "";
				if ( $movefile && ! isset( $movefile['error'] ) ) {
					$imageurl = $movefile['url'];
					update_option('payment_logo',$imageurl);
				} else {
					echo $movefile['error'];
				}
			}

		}


		?>
        <h1>Settings</h1>
        <form action="" name="payment_form" method="post" enctype="multipart/form-data">
            <!--            	<form action="options.php" method="post" enctype="multipart/form-data">-->
			<?php
			settings_fields( 'payment-settings' ); ?>
            <table class="form-table" role="presentation">
                <tbody>
                <tr class="stripe-id-wrap">
                    <th><label for="payment_stripe_id">Stripe Secret Key</label></th>
                    <td><input type="password" name="payment_stripe_id" id="stripe_id"
                               value="<?= $payment_stripe_id; ?>" class="regular-text"></td>
                </tr>

                <tr class="stripe-key-wrap">
                    <th><label for="payment_stripe_key">Stripe Publish Key</label></th>
                    <td><input type="text" name="payment_stripe_key" id="payment_stripe_key"
                               value="<?= $payment_stripe_key; ?>"   class="regular-text"></td>
                </tr>

                <tr class="active-wrap">
                    <th><label for="payment_active">Active</label></th>
                    <td><input type="text" name="payment_active" id="payment_active"
                               value="<?= $payment_active; ?>"	   class="regular-text"></td>
                </tr>
                <tr class="active-wrap">
                    <th><label for="payment_amount">Amount</label></th>
                    <td><input type="text" name="payment_amount" id="payment_amount"
                               value="<?= $payment_amount; ?>"     class="regular-text"></td>
                </tr>

                <tr class="background-color-wrap">
                    <th><label for="payment_bg_color">Background Color</label></th>
                    <td><input type="color" name="payment_bg_color" id="payment_bg_color"
                               value="<?= $payment_bg_color; ?>"  class="regular-text"></td>
                </tr>

                <tr class="cancel-url-wrap">
                    <th><label for="payment_cancel_payment_url">Cancel Payment Url</label></th>
                    <td><input type="text" name="payment_cancel_payment_url" id="payment_cancel_payment_url"
                               value="<?= $payment_cancel_payment_url; ?>"   class="regular-text"></td>
                </tr>
                <tr class="cancel-url-wrap">
                    <th><label for="payment_logo">Logo</label></th>
                    <td><input type="file" name="payment_logo" id="payment_logo"
                               class="regular-text"></td>
                </tr>

                </tbody>
            </table>
			<?php if($payment_logo){ ?>
                <div clas="image-payment" style="position: relative;width: 300px;height: 80px;">
                    <img src="<?= $payment_logo?>" style="width:70px;height:70px;position: absolute;right: 20px;" />
                </div>
			<?php } ?>
			<?php	//	do_settings_sections( 'payment-settings' );
			submit_button( 'Save Changes' );
			?>

        </form>
		<?php
		$content = ob_get_clean();
		echo $content;
	}


	public function menu_page_output()
	{
		//Menu Page output code
	}

	public function custom_post_css()
	{
		echo '<style type="text/css" media="screen">
        #adminmenu .menu-icon-payments div.wp-menu-image:before{
            font-family: "Font Awesome 5 Free";
            content: "\f53a"; 
            display: inline-block;
            padding-right: 3px;
            vertical-align: middle;
            font-weight: 900;
        } 
     </style>';
	}

	function init_remove_support()
	{
		$post_type = 'payments';
		remove_post_type_support( $post_type, 'title' );
		remove_post_type_support( $post_type, 'editor' );
	}

	function remove_publish_metabox()
	{
		if ( $_GET['action'] == 'edit' ) {
			remove_meta_box( 'submitdiv', 'payments', 'side' );
		}
//
	}

	function custom_fields_payment( $post )
	{
		$id      = $_GET['post'];
		$is_edit = ( $_GET['action'] == null ) ? false : true;
		if ( $_GET['action'] == null ) {
			$count = wp_count_posts( 'payments' )->publish + 1;
			$title = 'Transaction# ' . $count;
		} else {
			$title = get_the_title( $id );
		}
		$scr = get_current_screen()->id;

		if ( $scr == 'payments' ) {
			?>
            <h1><?= $title ?></h1>
            <input type="hidden" name="post_title" value="<?= $title ?>">

            <table class="form-table" role="presentation">
                <tbody>
                <tr class="first-name-wrap">
                    <th><label for="first_name">First Name</label></th>
                    <td><input type="text" name="first_name" id="first_name"
                               value="<?= get_post_meta( $id, 'first_name', true ); ?>" <?= ( $is_edit ) ? 'disabled' : '' ?>
                               class="regular-text"></td>
                </tr>

                <tr class="last-name-wrap">
                    <th><label for="last_name">Last Name</label></th>
                    <td><input type="text" name="last_name" id="last_name"
                               value="<?= get_post_meta( $id, 'last_name', true ); ?>" <?= ( $is_edit ) ? 'disabled' : '' ?>
                               class="regular-text"></td>
                </tr>
                <tr class="last-name-wrap">
                    <th><label for="last_name">Email</label></th>
                    <td><input type="text" name="email" id="email"
                               value="<?= get_post_meta( $id, 'email', true ); ?>" <?= ( $is_edit ) ? 'disabled' : '' ?>
                               class="regular-text"></td>
                </tr>

                <tr class="amount-wrap">
                    <th><label for="amount">Amount</label></th>
                    <td><input type="text" name="amount" id="amount"
                               value="<?= get_post_meta( $id, 'amount', true ); ?>" <?= ( $is_edit ) ? 'disabled' : '' ?>
                               class="regular-text"></td>
                </tr>

                <tr class="address1-wrap">
                    <th><label for="address1">Address 1</label></th>
                    <td><input type="text" name="address1" id="address1"
                               value="<?= get_post_meta( $id, 'address1', true ); ?>" <?= ( $is_edit ) ? 'disabled' : '' ?>
                               class="regular-text"></td>
                </tr>

                <tr class="address2-wrap">
                    <th><label for="address2">Address 2</label></th>
                    <td><input type="text" name="address2" id="address2"
                               value="<?= get_post_meta( $id, 'address2', true ); ?>" <?= ( $is_edit ) ? 'disabled' : '' ?>
                               class="regular-text"></td>
                </tr>

                <tr class="city-wrap">
                    <th><label for="city">City</label></th>
                    <td><input type="text" name="city" id="city"
                               value="<?= get_post_meta( $id, 'city', true ); ?>" <?= ( $is_edit ) ? 'disabled' : '' ?>
                               class="regular-text"></td>
                </tr>

                <tr class="state-wrap">
                    <th><label for="city">State</label></th>
                    <td><input type="text" name="state" id="state"
                               value="<?= get_post_meta( $id, 'state', true ); ?>" <?= ( $is_edit ) ? 'disabled' : '' ?>
                               class="regular-text"></td>
                </tr>

                <tr class="zip-wrap">
                    <th><label for="zip">Zip</label></th>
                    <td><input type="text" name="zip" id="zip"
                               value="<?= get_post_meta( $id, 'zip', true ); ?>" <?= ( $is_edit ) ? 'disabled' : '' ?>
                               class="regular-text"></td>
                </tr>

                <tr class="date-wrap">
                    <th><label for="date">Date</label></th>
                    <td><input type="text" name="date" id="date"
                               value="<?= get_post_meta( $id, 'date', true ); ?>" <?= ( $is_edit ) ? 'disabled' : '' ?>
                               class="regular-text"></td>
                </tr>

                <tr class="memo-wrap">
                    <th><label for="memo">Memo</label></th>
                    <td><input type="text" name="memo" id="memo"
                               value="<?= get_post_meta( $id, 'memo', true ); ?>" <?= ( $is_edit ) ? 'disabled' : '' ?>
                               class="regular-text"></td>
                </tr>
                <tr class="transaction-wrap">
                    <th><label for="transaction-id">Transaction ID</label></th>s
                    <td><input type="text" name="transaction-id" id="transaction-id"
                               value="<?= get_post_meta( $id, 'transaction-id', true ); ?>" <?= ( $is_edit ) ? 'disabled' : '' ?>
                               class="regular-text"></td>
                </tr>


                </tbody>
            </table>
			<?php
		}
	}

	function filter_post_data( $data, $postarr )
	{

		if ( $postarr['post_type'] == 'payments' && $postarr['original_publish'] == 'Publish' ) {
			update_post_meta( $postarr['ID'], 'first_name', $postarr['first_name'] );
			update_post_meta( $postarr['ID'], 'last_name', $postarr['last_name'] );
			update_post_meta( $postarr['ID'], 'email', $postarr['email'] );
			update_post_meta( $postarr['ID'], 'amount', $postarr['amount'] );
			update_post_meta( $postarr['ID'], 'city', $postarr['city'] );
			update_post_meta( $postarr['ID'], 'state', $postarr['state'] );
			update_post_meta( $postarr['ID'], 'address1', $postarr['address1'] );
			update_post_meta( $postarr['ID'], 'address2', $postarr['address2'] );
			update_post_meta( $postarr['ID'], 'date', $postarr['date'] );
			update_post_meta( $postarr['ID'], 'memo', $postarr['memo'] );
			update_post_meta( $postarr['ID'], 'zip', $postarr['zip'] );
			update_post_meta( $postarr['ID'], 'transaction-id', $postarr['transaction-id'] );
		}

		return $data;
	}

	function unserializeForm($str) {
		$strArray = explode("&", $str);
		foreach($strArray as $key => $item) {
			$array = explode("=", $item);
			$returndata[] = $array;
		}
		return $returndata;
	}

	function smashing_payments_columns( $columns ) {
		$columns = array(
			'cb' => $columns['cb'],
			'title' => __( 'Title'),
			'last_name' => __( 'Last Name', 'last_name' ),
			'first_name' => __( 'First Name', 'first_name' ),
			'Email' => __( 'Email', 'email' ),
			'amount' => __( 'Amount', 'amount' ),
			'invoice_ref' => __( 'Invoice Ref', 'invoice_ref' ),
			'date' => __( 'Date', 'date' ),
		);
		return $columns;
	}


	function custom_payments_column( $column, $post_id ) {
		if ( 'first_name' === $column ) {
			echo get_post_meta( $post_id, 'first_name' , true );
		}
		if ( 'city' === $column ) {
			echo get_post_meta( $post_id, 'city' , true );
		}
		if ( 'zip' === $column ) {
			echo get_post_meta( $post_id, 'zip' , true );
		}
	}

}

