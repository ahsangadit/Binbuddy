<?php

/**
 * Fired during plugin activation
 *
 * @link       https://hztech.biz
 * @since      1.0.0
 *
 * @package    Payment_Plugin
 * @subpackage Payment_Plugin/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Payment_Plugin
 * @subpackage Payment_Plugin/includes
 * @author     HZTECH <info@hztech.biz>
 */
class Payment_Plugin_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
